using System;

namespace MultiHitechERP.API.DTOs.Response
{
    /// <summary>
    /// Response DTO for material requisition item data
    /// </summary>
    public class MaterialRequisitionItemResponse
    {
        public int Id { get; set; }
        public int RequisitionId { get; set; }
        public int LineNo { get; set; }

        // Raw material fields
        public int? MaterialId { get; set; }
        public string? MaterialCode { get; set; }
        public string? MaterialName { get; set; }
        public string? MaterialGrade { get; set; }

        // Purchased component fields (mutually exclusive with MaterialId)
        public int? ComponentId { get; set; }
        public string? ComponentCode { get; set; }
        public string? ComponentName { get; set; }

        public decimal QuantityRequired { get; set; }
        public string? UOM { get; set; }
        public decimal? LengthRequiredMM { get; set; }
        public decimal? DiameterMM { get; set; }
        public int? NumberOfPieces { get; set; }

        public decimal? QuantityAllocated { get; set; }
        public decimal? QuantityIssued { get; set; }
        public decimal? QuantityPending { get; set; }

        public string Status { get; set; } = string.Empty;

        public int? JobCardId { get; set; }
        public string? JobCardNo { get; set; }
        public int? ProcessId { get; set; }
        public string? ProcessName { get; set; }

        /// <summary>
        /// List of pre-selected material piece IDs for this requisition item
        /// </summary>
        public List<int>? SelectedPieceIds { get; set; }

        public string? Remarks { get; set; }
        public DateTime? AllocatedAt { get; set; }
        public DateTime? IssuedAt { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
