using System;

namespace MultiHitechERP.API.DTOs.Response
{
    /// <summary>
    /// Response DTO for material issue data
    /// </summary>
    public class MaterialIssueResponse
    {
        public int Id { get; set; }
        public string IssueNo { get; set; } = string.Empty;
        public DateTime IssueDate { get; set; }

        public int RequisitionId { get; set; }
        public string? JobCardNo { get; set; }
        public string? OrderNo { get; set; }

        public string? MaterialName { get; set; }
        public string? MaterialGrade { get; set; }

        public int? TotalPieces { get; set; }
        public decimal? TotalIssuedLengthMM { get; set; }
        public decimal? TotalIssuedWeightKG { get; set; }

        public string Status { get; set; } = string.Empty;

        public string? IssuedById { get; set; }
        public string? IssuedByName { get; set; }
        public string? ReceivedById { get; set; }
        public string? ReceivedByName { get; set; }
    }
}
